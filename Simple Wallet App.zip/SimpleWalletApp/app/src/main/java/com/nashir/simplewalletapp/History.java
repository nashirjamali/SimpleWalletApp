package com.nashir.simplewalletapp;

public class History {
    String date, description, type;
    int nominal;

    public History(String date, String description, String type, int nominal) {
        this.date = date;
        this.description = description;
        this.type = type;
        this.nominal = nominal;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getNominal() {
        return nominal;
    }

    public void setNominal(int nominal) {
        this.nominal = nominal;
    }
}
