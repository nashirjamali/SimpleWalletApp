package com.nashir.simplewalletapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class AddRecord extends AppCompatActivity {

    Toolbar toolbar;
    TextView txtDateTime, txtSave;
    EditText etDesc, etNominal;
    RadioGroup rgType;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);
        db = new DatabaseHelper(this);
        initView();
        setSupportActionBar(toolbar);

        toolbar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_close_black_24dp));
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        txtSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();
            }
        });

    }

    private void initView(){
        toolbar = findViewById(R.id.toolbar);
        txtDateTime = findViewById(R.id.txtDateTime);
        txtSave = findViewById(R.id.txtSimpan);
        etDesc = findViewById(R.id.etUraian);
        etNominal = findViewById(R.id.etNominal);
        rgType = findViewById(R.id.rgTipe);
    }

    private void insertData(){
        int selectedId = rgType.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) findViewById(selectedId);
        String type = radioButton.getText().toString();

        boolean isInserted =db.insertData(etDesc.getText().toString(), etNominal.getText().toString(), type);
        if (isInserted){
            Toast.makeText(AddRecord.this,"Data Ditambahkan", Toast.LENGTH_LONG).show();
            finish();
        }else {
            Toast.makeText(AddRecord.this,"Data Gagal Ditambahkan", Toast.LENGTH_LONG).show();
        }
    }
}
