package com.nashir.simplewalletapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    TextView txtTime;
    EditText etName, etNominal;
    RadioGroup rgType;
    RadioButton radioButton;
    Button btnAdd;
    Toolbar toolbar;
    ImageView btnAddData;

    RecyclerView rvHistory;

    private HistoryAdapter historyAdapter;
    private List<History> historyList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        initView();
//        getToday();
        loadData();

        setSupportActionBar(toolbar);

        btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddRecord.class);
                startActivity(intent);
            }
        });
    }

    private void initView(){
//        txtTime = findViewById(R.id.txtTime);
//        etName = findViewById(R.id.etName);
//        etNominal = findViewById(R.id.etNominal);
//        rgType = findViewById(R.id.rgType);
//        btnAdd = findViewById(R.id.btnAdd);
        toolbar = findViewById(R.id.toolbar);
        rvHistory = findViewById(R.id.rvHistory);
        btnAddData = findViewById(R.id.btnAddData);
    }

//    private void getToday(){
//        Date currentTime = Calendar.getInstance().getTime();
//        txtTime.setText(currentTime.toString());
//    }

    private void insertData(){

//        int selectedId = rgType.getCheckedRadioButtonId();
//        radioButton = (RadioButton) findViewById(selectedId);
//        String type = radioButton.getText().toString();
//
//        Log.d("Type xx", type);
//        Log.d("Name xx", etName.getText().toString());
//        Log.d("Nominal xx", etNominal.getText().toString());
//
//        boolean isInserted =db.insertData(etName.getText().toString(), etNominal.getText().toString(), type);
//
//        if (isInserted){
//            Toast.makeText(MainActivity.this,"Data Ditambahkan", Toast.LENGTH_LONG).show();
//        }else {
//            Toast.makeText(MainActivity.this,"Data Gagal Ditambahkan", Toast.LENGTH_LONG).show();
//        }
//        loadData();
    }

    public void loadData(){

        db = new DatabaseHelper(MainActivity.this);
        historyList = db.getAllData();
        historyAdapter = new HistoryAdapter(historyList);


        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
        rvHistory.setLayoutManager(mLayoutManager);
        rvHistory.setItemAnimator(new DefaultItemAnimator());
        rvHistory.setAdapter(historyAdapter);
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        loadData();
    }
}
