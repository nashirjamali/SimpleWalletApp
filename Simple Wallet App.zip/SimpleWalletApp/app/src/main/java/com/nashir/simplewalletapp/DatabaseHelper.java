package com.nashir.simplewalletapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {


    private static final String DATABASE_NAME = "wallet.db";
    public static final String TABLE_NAME = "wallet_table";
    private static final int DATABASE_VERSION = 2;

    public static final String COL_1 = "ID";
    public static final String COL_2 = "TIME";
    public static final String COL_3 = "NAME";
    public static final String COL_4 = "NOMINAL";
    public static final String COL_5 = "TYPE";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table wallet_table (id integer primary key autoincrement," +
                "time DATETIME DEFAULT CURRENT_TIMESTAMP," +
                "name text," +
                "nominal integer," +
                "type text);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData(String name, String nominal, String type){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COL_3, name);
        contentValues.put(COL_4, nominal);
        contentValues.put(COL_5, type);

        long result = db.insert(TABLE_NAME, null, contentValues);

        if (result == -1){
            return false;
        }else {
            return  true;
        }
    }

    public List<History> getAllData(){
        List<History> historyList = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLE_NAME + " ORDER BY " + COL_2 + " DESC";
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()){
            do {
                History history = new History(cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(4),
                        cursor.getInt(3));
                historyList.add(history);
            }while (cursor.moveToNext());
        }

        return historyList;
    }

    public int getDataCount(){
        String sql = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        cursor.close();
        return cursor.getCount();
    }
}
