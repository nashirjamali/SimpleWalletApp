package com.nashir.simplewalletapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private List<History> historyList = new ArrayList<>();

    public HistoryAdapter(List<History> historyList) {
        this.historyList = historyList;
    }

    @NonNull
    @Override
    public HistoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_history, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryAdapter.ViewHolder holder, int position) {
        History history = historyList.get(position);
        holder.txtDate.setText(history.getDate());
        holder.txtNominal.setText(String.valueOf(history.getNominal()));
        holder.txtDesc.setText(history.getDescription());
    }

    @Override
    public int getItemCount() {
        return historyList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtDesc, txtNominal, txtDate;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtDesc = itemView.findViewById(R.id.txtDesc);
            txtNominal = itemView.findViewById(R.id.txtNominal);
            txtDate = itemView.findViewById(R.id.txtDate);
        }
    }
}
